# Figma Logo (Custom SVG)

This repository contains a custom SVG version of the Figma-style logo for design and development usage.

## Files Included
- `logo.svg` – Editable vector logo
- `index.html` – Preview in browser
- `style.css` – Basic styling
